# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build and Development Commands

### Package Building and Checking
- `devtools::document()` - Generate/update documentation from roxygen2 comments
- `devtools::check(cran = TRUE)` - Run comprehensive CRAN checks (this is the gold standard)
- `devtools::spell_check()` - Check spelling in documentation and DESCRIPTION
- `urlchecker::url_check()` - Validate all URLs in documentation
- `devtools::check_win_devel()` - Check on Windows development version
- `rhub::check_for_cran()` - Run multi-platform CRAN checks

### Testing
- `devtools::test()` - Run all tests
- `testthat::test_local()` - Run tests locally
- `testthat::test_file("tests/testthat/test_specific.R")` - Run a single test file
- Tests are located in `tests/testthat/`

### Documentation
- `pkgdown::build_site()` - Build the package website
- Documentation follows CRAN guidelines strictly (see CRAN_guidance.md)

## High-Level Architecture

fmrireg is an R package for fMRI time series regression analysis with a layered architecture:

### Core Abstractions

1. **Event System** (`R/event-classes.R`, `R/event_vector.R`)
   - `event_factor`: Categorical experimental events
   - `event_variable`: Continuous experimental variables
   - `event_matrix`: Matrix-based events
   - Events are convolved with HRFs to create regressors

2. **HRF System** (`R/hrf.R`, `R/hrf-*.R`)
   - Base `HRF` class with various implementations (gamma, gaussian, spline, etc.)
   - HRFs can be modified via decorators (lag, block, normalize)
   - Supports custom basis sets and parametric variations

3. **Model Hierarchy**
   - `baseline_model`: Nuisance regressors (drift, motion, etc.)
   - `event_model`: Experimental design (events + HRFs)
   - `fmri_model`: Complete model (baseline + events)

4. **Dataset Abstractions** (`R/fmri_dataset.R`)
   - `fmri_dataset`: Base class for fMRI data
   - `matrix_dataset`: In-memory matrix data
   - `fmri_mem_dataset`: Memory-mapped fMRI data
   - `latent_dataset`: Reduced dimensionality data

5. **Model Fitting** (`R/fmri_model.R`, `R/fmrilm.R`)
   - `fmri_lm`: Standard GLM fitting
   - `fmri_rlm`: Robust GLM fitting
   - Supports different strategies: runwise, chunkwise, trial-wise
   - C++ implementations for performance (mixed_solve, AR whitening)

6. **Contrast System** (`R/contrast.R`)
   - Flexible contrast specification via formulas
   - Support for F-contrasts, pairwise, polynomial contrasts

### Key Design Patterns

- **S3 Object System**: All generics defined in `R/all_generic.R`
- **Builder Pattern**: Models built incrementally (events → event_model → fmri_model)
- **Strategy Pattern**: Different fitting algorithms (OLS, robust, regularized)
- **Decorator Pattern**: HRF modifications (lag_hrf, block_hrf)

### Performance Considerations

- C++ implementations via Rcpp for computationally intensive operations
- Parallelization via RcppParallel (configurable: `options(fmrireg.num_threads = N)`)
- Chunked processing for large datasets to manage memory

### CRAN Compliance

The package strictly follows CRAN guidelines:
- S3 generics are the primary documentation site
- Methods use `@rdname` to link to generic documentation
- All examples must run quickly (< 5 seconds)
- Avoid modifying user options or par() without restoration
- See `CRAN_guidance.md` for detailed guidelines

### Development Principles

From `data-raw/principles.md`:
- Single source of truth for data representations
- Encapsulation over reconstruction
- Clear separation of concerns
- Functional composition preferred
- Object-oriented design with S3
- One way to do one thing
- Fail fast and locally with clear error messages