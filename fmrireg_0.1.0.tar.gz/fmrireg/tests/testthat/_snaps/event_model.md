# Golden heading test: diverse terms produce expected colnames

    Code
      colnames(dm_golden)
    Output
       [1] "Cond_condition.a"                    "Cond_condition.b"                   
       [3] "CondXMod_condition.a_modulator"      "CondXMod_condition.b_modulator"     
       [5] "StimRT_spmg3_stim_type.Face_rt_b01"  "StimRT_spmg3_stim_type.Scene_rt_b01"
       [7] "StimRT_spmg3_stim_type.Face_rt_b02"  "StimRT_spmg3_stim_type.Scene_rt_b02"
       [9] "StimRT_spmg3_stim_type.Face_rt_b03"  "StimRT_spmg3_stim_type.Scene_rt_b03"
      [11] "PolyX_01"                            "PolyX_02"                           
      [13] "PolyX_03"                            "ScaleYbyG_z_y_by_group"             
      [15] "Mod_CondA_modulator"                 "Mod_CondB_modulator"                

