library(testthat)
library(fmrireg)
Sys.setenv(R_TESTS="")
test_check("fmrireg")
